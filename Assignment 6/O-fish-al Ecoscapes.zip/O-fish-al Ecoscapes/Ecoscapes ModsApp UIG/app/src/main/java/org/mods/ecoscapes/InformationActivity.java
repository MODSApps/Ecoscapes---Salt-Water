package org.example.sudoku;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Roelle on 7/9/2015.
 */
public class InformationActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informationactivity);
    }
}
